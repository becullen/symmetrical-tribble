"""
https://towardsdatascience.com/time-series-forecasting-predicting-stock-prices-using-an-arima-model-2e3b3080bd70
https://matplotlib.org/3.1.0/gallery/color/named_colors.html
@author: pacif
"""
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.arima_model import ARIMA
from inputs import details, column
from sklearn.metrics import mean_squared_error, r2_score

def arima():
    '''Captures, splits data up into train and test data and calucates values to graph ARIMA model'''
    symbol, start_date, end_date, yfticker, company, stock_df = details()
    column_choice = column()
    
    train_data = stock_df[0:int(len(stock_df)*0.7)] 
    test_data = stock_df[int(len(stock_df)*0.7):]
    stock_df.index = (stock_df.index - pd.to_datetime("1900-01-01")).days
    training_data = train_data[column_choice].values
    test_data = test_data[column_choice].values
    his = [x for x in training_data] 
    model_predictions = []
    num_observations = len(test_data)
    test_set_range = pd.to_datetime(stock_df[int(len(stock_df) * 0.7):].index, 
                                    origin = "1900-01-01", unit = "D" )
    
    compute_values(num_observations, his, model_predictions, test_data)
    arima_text(test_data, model_predictions)
    plot(test_set_range,model_predictions, test_data, company, column_choice, stock_df)
    
def compute_values(num_observations, his, model_predictions, test_data):
    '''Calculates ARIMA model prediction values with the following ARIMA parameters: p=4, d=1, q=0'''    
    for time_point in range(num_observations):
        model = ARIMA(his, order=(4,1,0))
        model_fit = model.fit(disp=0) 
        output = model_fit.forecast()
        data_predict = output[0]
        model_predictions.append(data_predict)
        true_test_value = test_data[time_point] 
        his.append(true_test_value)
 
def arima_text(test_data, model_predictions):
    '''Calculates ARIMA model MSE & R2''' 
    print("\nMSE = ", round((mean_squared_error(test_data, model_predictions)), 4))
    print("R2 = ", round(r2_score(test_data, model_predictions), 4))
    
def plot(test_set_range, model_predictions, test_data, company, column_choice, stock_df):
    '''Plots ARMIA model'''
    plt.figure(figsize=(15,7))
    plt.plot(test_set_range, model_predictions, color="tab:blue", marker="o", linestyle="dashed",label="Predicted")
    plt.plot(test_set_range, test_data, color="gold", label="Actual")
    plt.title("{0} - {1} ARIMA".format(company, column_choice))
    plt.xlabel("Date")
    plt.ylabel("Price USD ($)")
    plt.legend(loc="upper left")
    plt.show()
















