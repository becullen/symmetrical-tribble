"""
https://towardsdatascience.com/a-comprehensive-guide-to-downloading-stock-prices-in-python-2cd93ff821d4
https://medium.com/trabe/building-rich-console-interfaces-in-python-16338cc30eaa
@author: pacif
"""

import yfinance as yf
from descriptivegraphs import raw_time_series, simple_moving, cumulative_moving, exponential_moving, macd
from arima import arima
from predict import linreg
from inputs import details
from message import Welcome

def first_message():
    '''Displays welcome message via a pop up window when user runs the program.'''
    Welcome
    
def display_menu():
    '''Prints main menu options.'''
    print("------------------------------------------------------------------------------------------------------------\n",\
          "\nMain Menu: \n1. Historical Data & Summary Statistics \n2. Graphical Displays",\
          "\n3. Predict Closing Price (Linear Regression)\n4. Export Stock Data to .CSV\n5. Quit Program")

def get_choice():
    '''Asks user for menu choice.'''
    return input("\nPlease choose a menu option: ")

def describe():
    '''Asks user for ticker and dates to display historical information and summary statistics.'''
    stock_df = None
    while stock_df is None:
        try:
            symbol, start_date, end_date, yfticker, company, stock_df = details()
            stock_df = yf.download(symbol, start_date, end_date, progress = False)  
            print("\n",company,"\nTicker =", symbol.upper(), "\nStart Date =", start_date,\
                  "\nEnd Date =", end_date, "\n\nSTOCK INFORMATION:\n", round(stock_df,2),\
                  "\n\nSUMMARY STATISTICS:\n", round((stock_df.describe()),2))
        except ValueError:
            print("Input not valid - please try again.")

def download_information():
    '''Asks user for ticker and dates to download the data as a .csv file.'''
    data = None
    while data is None:
        try:
            symbol, start_date, end_date, yfticker, company, stock_df = details()
            data = yf.download(symbol, start=start_date, end=end_date)
            data.to_csv(company + '.csv')
            print("\nData has been downloaded as: {}.csv".format(company))
            return data 
        except ValueError:
            print("Input not valid - please try again.")
            
def graph_display_menu():
    '''Prints graphical display menu options.'''
    print("------------------------------------------------------------------------------------------------------------\n",\
          "\nWhat kind of graph would you like to see? \n\n1. Raw Time Series \n2. Simple Moving Average",\
          "\n3. Cumulative Moving Average\n4. Exponential Moving Average\n5. Moving Average Convergence Divergence",\
          "\n6. ARIMA\n7. Return to Main Menu")

def graph_choice(choice2):
    '''Processes user graphical display choice.'''
    while choice2 != "7":
        if choice2 == "1": 
            raw_time_series() 
        elif choice2 == "2": 
            simple_moving()
        elif choice2 == "3": 
            cumulative_moving()
        elif choice2 == "4": 
            exponential_moving()
        elif choice2 == "5": 
            macd()
        elif choice2 == "6": 
            arima()
        else:  
            print("That menu option does not exist, please try again.")
        graph_display_menu()
        choice2 = get_choice()

def all_graphs():
    '''Displays and processes user graphical display choice.'''
    graph_display_menu()
    choice2 = get_choice()
    graph_choice(choice2)

def process_choice(choice):
    '''Processes user main menu choice.'''
    while choice != "5":
        if choice == "1": 
            describe() 
        elif choice == "2": 
            all_graphs()
        elif choice == "3": 
            linreg()
        elif choice == "4": 
            download_information()
        else:  
            print("That menu option does not exist, please try again.")
        display_menu()
        choice = get_choice()

def main():
    '''Displays welcome message, the main menu and processes user choices.'''
    first_message()
    display_menu()
    choice = get_choice()
    process_choice(choice)
    
if __name__ == "__main__":
    main()




















































