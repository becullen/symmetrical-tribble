"""
https://towardsdatascience.com/moving-averages-in-python-16170e20f6c
https://www.datacamp.com/community/tutorials/moving-averages-in-pandas
https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.rolling.html
https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.ewm.html
https://towardsdatascience.com/implementing-macd-in-python-cc9b2280126a
@author: pacif
"""

import matplotlib.pyplot as plt
from inputs import details, column, moving_avg_days, alpha

def plot_layout():
    '''Sets up graph format layout details'''
    plt.xlabel("Date")
    plt.ylabel("Price USD ($)")
    plt.ticklabel_format(axis = "y", style = "plain")
    plt.legend(loc="upper left")
    plt.show()
         
def raw_time_series():
    '''Graphs historical data with user column choice input.'''
    symbol, start_date, end_date, yfticker, company, stock_df = details()
    column_choice = column()
    stock_df[column_choice].plot(title ="{0} - {1}".format(company, "History"), color="gold", figsize = (15,7))
    plot_layout()

def simple_moving():
    '''Graphs simple moving average with user column choice input and # of days for moving average.'''
    symbol, start_date, end_date, yfticker, company, stock_df = details()
    column_choice = column()
    days = moving_avg_days()
    stock_df[column_choice].plot(label = column_choice, color="gold")
    stock_df["SMA"] = stock_df[column_choice].rolling(days).mean()
    stock_df["SMA"].plot(title = "{0} - Simple Moving Average".format(company), color="tab:blue", label = "{} SMA".format(days), figsize = (15,7))
    plot_layout()

def cumulative_moving():
    '''Graphs cumulative moving average with user column choice input.'''
    symbol, start_date, end_date, yfticker, company, stock_df = details()
    column_choice = column()
    stock_df[column_choice].plot(label = column_choice, color="gold")
    stock_df["CMA"] = stock_df[column_choice].expanding().mean()
    stock_df["CMA"].plot(title="{0} - Cumulative Moving Average".format(company), color="tab:blue", label = "CMA", figsize = (15,7))
    plot_layout()
    
def exponential_moving():    
    '''Graphs exponential moving average with user column choice input and value of alpha.'''
    symbol, start_date, end_date, yfticker, company, stock_df = details()
    column_choice = column()
    smoother = alpha()
    stock_df[column_choice].plot(label = column_choice, color="gold")
    stock_df["EMA"] = stock_df[column_choice].ewm(alpha = smoother, adjust = False).mean()
    stock_df["EMA"].plot(title="{0} - Exponential Moving Average".format(company), color="tab:blue", label = "{} EM".format(smoother), figsize = (15,7))
    plot_layout()

def macd():
    '''Graphs moving average convergence divergence with user column choice input.'''
    symbol, start_date, end_date, yfticker, company, stock_df = details()
    column_choice = column()
    exp1 = stock_df[column_choice].ewm(span=12, adjust=False).mean()
    exp2 = stock_df[column_choice].ewm(span=26, adjust=False).mean()
    signal = stock_df[column_choice].ewm(span=9, adjust=False).mean()
    macd = exp1 - exp2
    macd.plot(label="MACD", color="orange", figsize = (15,7))
    signal.plot(label="Signal Line", color="tab:blue", figsize = (15,7))
    stock_df[column_choice].plot(label= "{}".format(company), color="gold")
    plt.title("{0} - {1} MACD".format(company, column_choice))
    plot_layout()
 





