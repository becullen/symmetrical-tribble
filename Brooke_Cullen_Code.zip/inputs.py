"""
@author: pacif
"""
import yfinance as yf 

def details():
    '''Gets user input for ticker and dates.'''
    user_input = None
    while user_input is None:
        try:
            symbol = input("Enter Ticker Symbol: ") 
            start_date = input("Enter Start Date (YYYY-MM-DD): ")
            end_date = input("Enter End Date (YYYY-MM-DD): ")
            yfticker = yf.Ticker(symbol)
            company = yfticker.info['longName']
            stock_df = yfticker.history(period = "max", start = start_date, end = end_date) 
            return symbol, start_date, end_date, yfticker, company, stock_df
        except ValueError:
            print("Input not valid - please try again.")

def column():
    '''Gets user input for column selection for graphs.'''
    column_choice = input("Enter what you'd like to graph (Open, High, Low, Close): ")
    column_valid = ["Open", "High", "Low", "Close"]
    while column_choice not in column_valid:
        print("Input not valid - please try again.")
        column_choice = input("Enter what you'd like to graph (Open, High, Low, Close): ")
    return column_choice

def alpha():
    '''Gets user input for an alpha smoother in exponential moving graph.'''
    while True:
        try:
            smoother = float(input("Enter Smoothing Factor between 0 & 1 (eg 0.1): "))
            if 0<= smoother <= 1:
                return smoother
            else: print("Input not valid - please try again.")
        except ValueError:
            print("Input not valid - please try again.")

def moving_avg_days():  
    '''Gets user input for number of days in simple moving average graph.'''
    days = None
    while days is None:
        try:
            days = int(input("Enter number of days for the moving average: "))
            if days > 0:
                return days
            else: print("Input not valid - please try again.")
        except ValueError: 
            print("Input not valid - please try again.")

def predict_days():
    '''Gets user input for number of prediction days for linear regression model.'''
    future_days = None
    while future_days is None:
        try:
            future_days = int(input("Please type how many days in the future you'd like a prediction for: "))
            if future_days > 0:
                return future_days    
            else: print("Input not valid - please try again.")
        except ValueError: 
            print("Input not valid - please try again.") 
