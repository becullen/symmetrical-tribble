"""
https://stackoverflow.com/questions/23482748/how-to-create-a-hyperlink-with-a-label-in-tkinter
@author: pacif
"""

import tkinter as tk
from tkhtmlview import HTMLLabel

class Welcome:
    '''Displays program welcome messsage with link to the user guide via a pop up window.'''
    def __init__(self, master):
        self.master = master 
        master.title("MIS41110 Fall 2020")
        self.label = tk.Label(master, text = "\nWelcome to Brooke's Stock Application! \nPlease press \"Ready!\" or exit this window to continue\n in the command line.")
        self.label.pack(side = tk.TOP, expand=True)
        self.qbutton = tk.Button(master, text = "Ready!", bg="White", command = self.quit)
        self.qbutton.pack()
        self.html_label = HTMLLabel(root, html='<a href="https://drive.google.com/file/d/1-fRgsMvblilx2AoPzcKKrdhx4NO7DVy9/view?usp=sharing"> Link to program user guide. </a>')
        self.html_label.pack(fill="both", expand=True)
        self.html_label.fit_height()
        
    def quit(self):
        self.master.destroy()

root = tk.Tk() 
root.geometry("500x150") 
Welcome(root)
root.mainloop()

