"""
https://www.geeksforgeeks.org/python-pandas-to_datetime/
https://medium.com/@srkhedkar/stock-market-prediction-using-python-article-1-the-straight-line-c23f26579b4d
https://scikit-learn.org/stable/modules/generated/sklearn.metrics.r2_score.html
https://scikit-learn.org/stable/modules/generated/sklearn.metrics.mean_squared_error.html
https://numpy.org/doc/stable/reference/generated/numpy.around.html#:~:text=The%20real%20and%20imaginary%20parts,a%20float%20is%20a%20float.&text=For%20values%20exactly%20halfway%20between,0.5%20round%20to%200.0%2C%20etc.
@author: pacif
"""

import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, r2_score
from math import sqrt 
from inputs import details, column, predict_days

def linreg():  
    '''Calculates linear regression prediction model with user input number of days for prediction'''    
    symbol, start_date, end_date, yfticker, company, stock_df = details()
    column_choice = column()
    future_days = predict_days()
    
    stock_df.index = (stock_df.index - pd.to_datetime("1970-01-01")).days
    y_actual = np.asarray(stock_df[column_choice])
    x_actual = np.asarray(stock_df.index.values)
    
    regression_model = LinearRegression()
    regression_model.fit(x_actual.reshape(-1, 1), y_actual.reshape(-1, 1))  
    
    y_hist = regression_model.predict(x_actual.reshape(-1, 1)) 
    x_future = np.asarray(pd.RangeIndex(start=x_actual[-1], stop=x_actual[-1] + future_days)) 
    y_predict = regression_model.predict(x_future.reshape(-1, 1))
    x_actual = pd.to_datetime(stock_df.index, origin="1970-01-01", unit="D")
    x_future = pd.to_datetime(x_future, origin="1970-01-01", unit="D")
    print ("\nClosing price in {} days should be $".format(future_days), (np.around(y_predict[-1],2)))
    
    lr_text(y_actual, y_hist)
    lr_plot(x_actual, x_future, y_hist, y_predict,company,stock_df,column_choice)

def lr_text(y_actual, y_hist):
    '''Calculates RMSE & R2 from linear regression prediction model'''
    lr_mse = sqrt(mean_squared_error(y_actual, y_hist, squared = False))
    print("Linear Root MSE = ", round(lr_mse, 4))
    R2 = r2_score(y_actual, y_hist)
    print("Linear R2 = ", round(R2,4))
    return round(lr_mse, 4), round(R2,4)

def lr_plot(x_actual, x_future, y_hist, y_predict, company, stock_df, column_choice):
    '''Plots the linear regression prediction model'''
    plt.figure(figsize=(16,8))
    plt.plot(x_actual,stock_df["Close"], color="gold", label="Price History")
    plt.plot(x_actual,y_hist, color="tab:blue", label="Mathematical Model")
    plt.plot(x_future,y_predict, color="orange", label="Future Predictions")
    plt.title("{0} {1} Price Predictions".format(company, column_choice))
    plt.xlabel("Date")
    plt.ylabel("Price USD ($)")
    plt.legend(loc="upper left")
    plt.show()
